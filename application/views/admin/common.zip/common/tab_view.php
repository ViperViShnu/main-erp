<?php
$this->load->view('admin/common/tabs');
?>